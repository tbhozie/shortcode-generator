ace.define("ace/snippets/elixir",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope=""});
                (function() {
                    ace.require(["ace/snippets/elixir"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            